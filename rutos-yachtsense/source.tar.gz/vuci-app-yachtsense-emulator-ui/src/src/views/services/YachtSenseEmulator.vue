<template>
  <div>
    <tlt-card :title="$t('YachtSense Link status')">
      <div class="status-grid">
        <div class="status-item">
          <span class="status-label">{{ $t("Service") }}</span>
          <span :class="['status-value', runtime.running ? 'ok' : 'off']">
            {{ runtime.running ? $t("Running") : $t("Stopped") }}
            <template v-if="runtime.pid"> (PID {{ runtime.pid }})</template>
          </span>
        </div>
        <div class="status-item">
          <span class="status-label">{{ $t("Interface") }}</span>
          <span :class="['status-value', runtime.interface_exists ? 'ok' : 'bad']">
            {{ config.interface || "-" }}
          </span>
        </div>
        <div class="status-item">
          <span class="status-label">{{ $t("RayNet address") }}</span>
          <span :class="['status-value', runtime.address_present ? 'ok' : 'off']">
            {{ config.ip || "-" }}/{{ config.prefix || "-" }}
          </span>
        </div>
        <div class="status-item">
          <span class="status-label">{{ $t("mDNS advertisement") }}</span>
          <span :class="['status-value', runtime.mdns_active ? 'ok' : 'off']">
            {{ runtime.mdns_active ? $t("Active") : $t("Inactive") }}
          </span>
        </div>
        <div class="status-item">
          <span class="status-label">{{ $t("HTTP probe service") }}</span>
          <span :class="['status-value', runtime.web_active ? 'ok' : 'off']">
            {{ runtime.web_active ? $t("Active") : $t("Inactive") }}
          </span>
        </div>
        <div class="status-item">
          <span class="status-label">{{ $t("Advertised product ID") }}</span>
          <span class="status-value">E70640 {{ config.serial || "-" }}</span>
        </div>
      </div>

      <div class="button-row">
        <tlt-button @click="runAction('start')">{{ $t("Start") }}</tlt-button>
        <tlt-button @click="runAction('stop')">{{ $t("Stop") }}</tlt-button>
        <tlt-button @click="runAction('restart')">{{ $t("Restart") }}</tlt-button>
        <tlt-button @click="refreshAll">{{ $t("Refresh") }}</tlt-button>
      </div>
    </tlt-card>

    <vuci-form v-slot="{ uciData }" config="yachtsense_emulator" async-load>
      <vuci-named-section
        v-slot="{ s }"
        name="main"
        data-key="yachtsense"
        :uci-data="uciData"
        :endpoints="[{ endpoint: 'yachtsense_c/config' }]"
        :title="$t('YachtSense Link emulator')"
      >
        <vuci-form-item-switch
          :uci-section="s"
          name="enabled"
          :label="$t('Enable emulator')"
          :help="$t('Start the emulator automatically and keep it running with procd.')"
        />
        <vuci-form-item-switch
          :uci-section="s"
          name="mdns_enabled"
          :label="$t('Enable mDNS service')"
          :help="$t('Advertise _http._tcp.local with YachtSense product ID E70640.')"
        />
        <vuci-form-item-switch
          :uci-section="s"
          name="web_enabled"
          :label="$t('Enable HTTP probe service')"
          :help="$t('Answer the Axiom connectivity probe, normally on TCP port 7777.')"
        />
        <vuci-form-item-select
          :uci-section="s"
          name="interface"
          :label="$t('Interface')"
          :options="interfaceOptions"
          :help="$t('Select the Ethernet bridge or VLAN connected to the Axiom/RayNet network.')"
        />
        <vuci-form-item-switch
          :uci-section="s"
          name="manage_ip"
          :label="$t('Manage RayNet address')"
          :help="$t('Add the configured 198.18.x.x address to the selected interface while the service runs.')"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="ip"
          :label="$t('RayNet IPv4 address')"
          maxlength="15"
          :help="$t('Default: 198.18.0.1')"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="prefix"
          :label="$t('Prefix length')"
          maxlength="2"
          :help="$t('Default: 21 (255.255.248.0)')"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="web_port"
          :label="$t('HTTP probe port')"
          maxlength="5"
          :help="$t('Default: 7777')"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="serial"
          :label="$t('Advertised serial')"
          maxlength="32"
          :help="$t('The TXT record becomes: id=E70640 <serial>.')"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="version"
          :label="$t('Advertised version')"
          maxlength="48"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="hostname"
          :label="$t('mDNS hostname')"
          maxlength="63"
          :help="$t('Published as <hostname>.local.')"
        />
        <vuci-form-item-input
          :uci-section="s"
          name="instance"
          :label="$t('Service instance name')"
          maxlength="63"
          :help="$t('Default: RUTX14 Settings')"
        />
        <vuci-form-item-switch
          :uci-section="s"
          name="remove_ip_on_stop"
          :label="$t('Remove managed address on stop')"
        />
      </vuci-named-section>
    </vuci-form>

    <tlt-card :title="$t('Recent log')">
      <pre class="log-box">{{ logs }}</pre>
      <div class="button-row">
        <tlt-button @click="loadLogs">{{ $t("Refresh log") }}</tlt-button>
      </div>
    </tlt-card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      runtime: {
        running: false,
        pid: null,
        interface_exists: false,
        address_present: false,
        mdns_active: false,
        web_active: false,
      },
      config: {
        interface: "br-lan",
        ip: "198.18.0.1",
        prefix: 21,
        serial: "RUTX001",
      },
      interfaceOptions: [["br-lan", "br-lan"]],
      logs: this.$t("Loading..."),
      statusTimer: null,
      logTimer: null,
    };
  },
  mounted() {
    this.refreshAll();
    this.statusTimer = window.setInterval(this.loadStatus, 5000);
    this.logTimer = window.setInterval(this.loadLogs, 10000);
  },
  beforeUnmount() {
    if (this.statusTimer) window.clearInterval(this.statusTimer);
    if (this.logTimer) window.clearInterval(this.logTimer);
  },
  methods: {
    unwrap(response) {
      let value = response;
      if (value && value.data !== undefined) value = value.data;
      if (value && value.data !== undefined) value = value.data;
      return value || {};
    },
    async loadStatus() {
      try {
        const response = await this.$axios.get("/api/yachtsense_f/status");
        const data = this.unwrap(response);
        this.runtime = { ...this.runtime, ...(data.runtime || {}) };
        this.config = { ...this.config, ...(data.config || {}) };
      } catch {
        this.runtime.running = false;
      }
    },
    async loadInterfaces() {
      try {
        const response = await this.$axios.get("/api/yachtsense_f/interfaces");
        const data = this.unwrap(response);
        const options = (data.interfaces || []).map((item) => [item.name, item.label]);
        if (options.length) this.interfaceOptions = options;
      } catch {
        this.$message.error(this.$t("Failed to load interfaces"));
      }
    },
    async loadLogs() {
      try {
        const response = await this.$axios.get("/api/yachtsense_f/logs");
        const data = this.unwrap(response);
        this.logs = data.logs || this.$t("No log entries yet.");
      } catch {
        this.logs = this.$t("Failed to load log.");
      }
    },
    async refreshAll() {
      await Promise.all([this.loadStatus(), this.loadInterfaces(), this.loadLogs()]);
    },
    async runAction(action) {
      this.$spin();
      try {
        await this.$axios.post(`/api/yachtsense_f/actions/${action}`, { data: {} });
        this.$message.success(this.$t("Action executed"));
        window.setTimeout(this.refreshAll, 700);
      } catch {
        this.$message.error(this.$t("Action failed"));
      } finally {
        this.$spin(false);
      }
    },
  },
};
</script>

<style scoped>
.status-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px;
  margin-bottom: 16px;
}
.status-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 12px;
  border: 1px solid rgba(127, 127, 127, 0.25);
  border-radius: 4px;
}
.status-label {
  opacity: 0.72;
  font-size: 0.9rem;
}
.status-value {
  font-weight: 600;
  overflow-wrap: anywhere;
}
.status-value.ok { color: #238636; }
.status-value.off { opacity: 0.65; }
.status-value.bad { color: #c62828; }
.button-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 12px;
}
.log-box {
  min-height: 180px;
  max-height: 360px;
  overflow: auto;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  padding: 12px;
  border: 1px solid rgba(127, 127, 127, 0.25);
  border-radius: 4px;
  background: rgba(127, 127, 127, 0.08);
}
</style>
