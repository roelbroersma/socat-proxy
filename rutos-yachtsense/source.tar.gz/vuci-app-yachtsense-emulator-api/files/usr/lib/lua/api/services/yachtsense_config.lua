local ConfigService = require("api/ConfigService")
local fs = require("nixio.fs")
local util = require("vuci.util")

local Service = ConfigService:new({
	delete = false,
	create = false,
	general_section = "main"
})

local Config = Service:section("yachtsense_emulator", "yachtsense")
Config:make_primary()

local function valid_ipv4(value)
	if type(value) ~= "string" then return false end
	local a, b, c, d = value:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
	if not a then return false end
	for _, octet in ipairs({ a, b, c, d }) do
		local number = tonumber(octet)
		if not number or number < 0 or number > 255 then return false end
	end
	return true
end

local function bool_option(name)
	local option = Config:option(name)
	function option:validate(value)
		return self.dt:is_bool(value)
	end
	return option
end

bool_option("enabled")
bool_option("mdns_enabled")
bool_option("web_enabled")
bool_option("manage_ip")
bool_option("remove_ip_on_stop")

local interface = Config:option("interface")
interface.cfg_require = true
interface.maxlength = 32
function interface:validate(value)
	return type(value) == "string"
		and value:match("^[%w%._:@%-]+$") ~= nil
		and fs.stat("/sys/class/net/" .. value) ~= nil
end

local ip = Config:option("ip")
ip.cfg_require = true
ip.maxlength = 15
function ip:validate(value)
	return valid_ipv4(value)
end

local prefix = Config:option("prefix")
prefix.cfg_require = true
function prefix:validate(value)
	local number = tonumber(value)
	return number ~= nil and number >= 1 and number <= 32 and number == math.floor(number)
end

local serial = Config:option("serial")
serial.cfg_require = true
serial.maxlength = 32
function serial:validate(value)
	return type(value) == "string" and value:match("^[%w_%-]+$") ~= nil
end

local version = Config:option("version")
version.cfg_require = true
version.maxlength = 48
function version:validate(value)
	return type(value) == "string" and value:match("^[%w%._%-]+$") ~= nil
end

local hostname = Config:option("hostname")
hostname.cfg_require = true
hostname.maxlength = 63
function hostname:validate(value)
	return type(value) == "string" and value:match("^[%w%-]+$") ~= nil
end

local instance = Config:option("instance")
instance.cfg_require = true
instance.maxlength = 63
function instance:validate(value)
	return type(value) == "string"
		and value:match("^[%w _%-]+$") ~= nil
		and not value:find("%.")
end

local web_port = Config:option("web_port")
web_port.cfg_require = true
function web_port:validate(value)
	local number = tonumber(value)
	return number ~= nil and number >= 1 and number <= 65535 and number == math.floor(number)
end

local function restart_service()
	util.file_exec("/etc/init.d/yachtsense-emulator", { "restart" })
end

function Service:POST_after_commit_hook()
	restart_service()
end

function Service:PUT_after_commit_hook()
	restart_service()
end

return Service
