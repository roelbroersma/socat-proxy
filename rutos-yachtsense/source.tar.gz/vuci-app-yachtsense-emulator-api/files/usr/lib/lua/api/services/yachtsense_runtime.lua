local FunctionService = require("api/FunctionService")
local fs = require("nixio.fs")
local uci = require("uci").cursor()
local util = require("vuci.util")

local Runtime = FunctionService:new()
local CONFIG = "yachtsense_emulator"
local SECTION = "main"

local function shell_quote(value)
	value = tostring(value or "")
	return "'" .. value:gsub("'", "'\\''") .. "'"
end

local function get_option(name, default)
	local value = uci:get(CONFIG, SECTION, name)
	if value == nil or value == "" then return default end
	return value
end

local function as_bool(value)
	return value == true or value == 1 or value == "1" or value == "true"
end

local function read_config()
	return {
		enabled = as_bool(get_option("enabled", "0")),
		mdns_enabled = as_bool(get_option("mdns_enabled", "1")),
		web_enabled = as_bool(get_option("web_enabled", "1")),
		interface = get_option("interface", "br-lan"),
		manage_ip = as_bool(get_option("manage_ip", "1")),
		ip = get_option("ip", "198.18.0.1"),
		prefix = tonumber(get_option("prefix", "21")) or 21,
		remove_ip_on_stop = as_bool(get_option("remove_ip_on_stop", "1")),
		serial = get_option("serial", "RUTX001"),
		version = get_option("version", "V142.242.530"),
		hostname = get_option("hostname", "yachtsense"),
		instance = get_option("instance", "RUTX14 Settings"),
		web_port = tonumber(get_option("web_port", "7777")) or 7777
	}
end

local function process_id()
	local output = util.trim(util.exec("pidof yachtsense-emulator 2>/dev/null") or "")
	return output:match("^(%d+)")
end

local function address_present(config)
	if not config.interface:match("^[%w%._:@%-]+$") then return false end
	local command = "ip -4 -o addr show dev " .. shell_quote(config.interface) .. " 2>/dev/null"
	local output = util.exec(command) or ""
	return output:find(" " .. config.ip .. "/", 1, true) ~= nil
end

local function listening_on(port, protocol)
	local command = protocol == "udp" and "netstat -lnu 2>/dev/null" or "netstat -lnt 2>/dev/null"
	local output = util.exec(command) or ""
	return output:match(":" .. tostring(port) .. "%s") ~= nil
end

local function runtime_status()
	local config = read_config()
	local pid = process_id()
	return {
		running = pid ~= nil,
		pid = pid and tonumber(pid) or nil,
		interface_exists = fs.stat("/sys/class/net/" .. config.interface) ~= nil,
		address_present = address_present(config),
		mdns_active = pid ~= nil and config.mdns_enabled and listening_on(5353, "udp"),
		web_active = pid ~= nil and config.web_enabled and listening_on(config.web_port, "tcp")
	}, config
end

function Runtime:GET_TYPE_status()
	local runtime, config = runtime_status()
	return self:ResponseOK({ runtime = runtime, config = config })
end

function Runtime:GET_TYPE_interfaces()
	local interfaces = {}
	local iterator = fs.dir("/sys/class/net")
	if iterator then
		for name in iterator do
			if name ~= "lo" and name:match("^[%w%._:@%-]+$") then
				local output = util.exec("ip -4 -o addr show dev " .. shell_quote(name) .. " 2>/dev/null") or ""
				local addresses = {}
				for address in output:gmatch("inet%s+([%d%.]+/%d+)") do
					table.insert(addresses, address)
				end
				table.insert(interfaces, {
					name = name,
					addresses = addresses,
					label = #addresses > 0 and (name .. " (" .. table.concat(addresses, ", ") .. ")") or name
				})
			end
	end
	table.sort(interfaces, function(a, b)
		if a.name == "br-lan" then return true end
		if b.name == "br-lan" then return false end
		return a.name < b.name
	end)
	return self:ResponseOK({ interfaces = interfaces })
end

function Runtime:GET_TYPE_logs()
	local output = util.exec("logread -e yachtsense-emulator 2>/dev/null | tail -n 60") or ""
	if output == "" then output = "Nog geen logregels." end
	return self:ResponseOK({ logs = output })
end

local function perform_action(self, action)
	local allowed = { start = true, stop = true, restart = true }
	if not allowed[action] then
		return self:ResponseError(400, "Unsupported action")
	end
	local result = util.file_exec("/etc/init.d/yachtsense-emulator", { action })
	local runtime, config = runtime_status()
	return self:ResponseOK({ action = action, result = result, runtime = runtime, config = config })
end

function Runtime:RestartAction()
	return perform_action(self, "restart")
end

function Runtime:StartAction()
	return perform_action(self, "start")
end

function Runtime:StopAction()
	return perform_action(self, "stop")
end

local restart_action = Runtime:action("restart", Runtime.RestartAction)
local start_action = Runtime:action("start", Runtime.StartAction)
local stop_action = Runtime:action("stop", Runtime.StopAction)

return Runtime
