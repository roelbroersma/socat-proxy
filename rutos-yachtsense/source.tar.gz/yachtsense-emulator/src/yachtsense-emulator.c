#define _GNU_SOURCE

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <syslog.h>
#include <time.h>
#include <unistd.h>

#ifndef SO_BINDTODEVICE
#define SO_BINDTODEVICE 25
#endif

#define MDNS_GROUP "224.0.0.251"
#define MDNS_PORT 5353
#define DNS_TTL 120U
#define ANNOUNCE_INTERVAL 60
#define MAX_PACKET 2048
#define MAX_NAME 256
#define MAX_TEXT 128

struct config {
    char iface[IFNAMSIZ];
    char ip[INET_ADDRSTRLEN];
    char serial[64];
    char version[64];
    char hostname[64];
    char instance[64];
    int web_port;
    bool mdns_enabled;
    bool web_enabled;
};

struct buffer {
    uint8_t data[MAX_PACKET];
    size_t len;
};

static volatile sig_atomic_t g_running = 1;
static int g_mdns_fd = -1;
static int g_web_fd = -1;
static struct config g_cfg;
static struct in_addr g_ip_addr;
static char g_mac[18] = "02:00:00:00:00:01";
static char g_host_fqdn[MAX_NAME];
static char g_service_type[] = "_http._tcp.local";
static char g_instance_fqdn[MAX_NAME];
static char g_services_browse[] = "_services._dns-sd._udp.local";

static void handle_signal(int signo)
{
    (void)signo;
    g_running = 0;
}

static void usage(const char *prog)
{
    fprintf(stderr,
            "Usage: %s --interface IFACE --ip IPV4 [options]\n"
            "  --mdns 0|1          Enable mDNS/DNS-SD advertisement\n"
            "  --web 0|1           Enable HTTP probe service\n"
            "  --web-port PORT     HTTP probe port (default 7777)\n"
            "  --serial TEXT       Product serial suffix\n"
            "  --version TEXT      Advertised firmware version\n"
            "  --hostname LABEL    Advertised .local hostname\n"
            "  --instance LABEL    DNS-SD service instance label\n",
            prog);
}

static bool parse_bool(const char *value, bool *out)
{
    if (!value || !out)
        return false;
    if (!strcmp(value, "1") || !strcasecmp(value, "true") || !strcasecmp(value, "yes")) {
        *out = true;
        return true;
    }
    if (!strcmp(value, "0") || !strcasecmp(value, "false") || !strcasecmp(value, "no")) {
        *out = false;
        return true;
    }
    return false;
}

static void copy_string(char *dest, size_t dest_size, const char *src)
{
    if (!dest || dest_size == 0)
        return;
    snprintf(dest, dest_size, "%s", src ? src : "");
}

static void sanitize_hostname(char *value)
{
    size_t write_pos = 0;
    for (size_t i = 0; value[i] != '\0' && write_pos < 63; i++) {
        unsigned char c = (unsigned char)value[i];
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-') {
            value[write_pos++] = (char)c;
        } else if (c == '.' || c == '_' || c == ' ') {
            value[write_pos++] = '-';
        }
    }
    while (write_pos > 0 && value[write_pos - 1] == '-')
        write_pos--;
    value[write_pos] = '\0';
    if (write_pos == 0)
        copy_string(value, 64, "yachtsense");
}

static void sanitize_instance(char *value)
{
    size_t write_pos = 0;
    for (size_t i = 0; value[i] != '\0' && write_pos < 63; i++) {
        unsigned char c = (unsigned char)value[i];
        if (c >= 32 && c <= 126 && c != '.')
            value[write_pos++] = (char)c;
        else if (c == '.')
            value[write_pos++] = '-';
    }
    while (write_pos > 0 && value[write_pos - 1] == ' ')
        write_pos--;
    value[write_pos] = '\0';
    if (write_pos == 0)
        copy_string(value, 64, "RUTX14 Settings");
}

static bool parse_args(int argc, char **argv)
{
    static const struct option options[] = {
        {"interface", required_argument, NULL, 'i'},
        {"ip", required_argument, NULL, 'a'},
        {"mdns", required_argument, NULL, 'm'},
        {"web", required_argument, NULL, 'w'},
        {"web-port", required_argument, NULL, 'p'},
        {"serial", required_argument, NULL, 's'},
        {"version", required_argument, NULL, 'v'},
        {"hostname", required_argument, NULL, 'h'},
        {"instance", required_argument, NULL, 'n'},
        {"help", no_argument, NULL, '?'},
        {NULL, 0, NULL, 0}
    };

    memset(&g_cfg, 0, sizeof(g_cfg));
    copy_string(g_cfg.iface, sizeof(g_cfg.iface), "br-lan");
    copy_string(g_cfg.ip, sizeof(g_cfg.ip), "198.18.0.1");
    copy_string(g_cfg.serial, sizeof(g_cfg.serial), "RUTX001");
    copy_string(g_cfg.version, sizeof(g_cfg.version), "V142.242.530");
    copy_string(g_cfg.hostname, sizeof(g_cfg.hostname), "yachtsense");
    copy_string(g_cfg.instance, sizeof(g_cfg.instance), "RUTX14 Settings");
    g_cfg.web_port = 7777;
    g_cfg.mdns_enabled = true;
    g_cfg.web_enabled = true;

    int opt;
    while ((opt = getopt_long(argc, argv, "i:a:m:w:p:s:v:h:n:?", options, NULL)) != -1) {
        switch (opt) {
        case 'i': copy_string(g_cfg.iface, sizeof(g_cfg.iface), optarg); break;
        case 'a': copy_string(g_cfg.ip, sizeof(g_cfg.ip), optarg); break;
        case 'm': if (!parse_bool(optarg, &g_cfg.mdns_enabled)) return false; break;
        case 'w': if (!parse_bool(optarg, &g_cfg.web_enabled)) return false; break;
        case 'p': {
            char *end = NULL;
            long port = strtol(optarg, &end, 10);
            if (!end || *end != '\0' || port < 1 || port > 65535)
                return false;
            g_cfg.web_port = (int)port;
            break;
        }
        case 's': copy_string(g_cfg.serial, sizeof(g_cfg.serial), optarg); break;
        case 'v': copy_string(g_cfg.version, sizeof(g_cfg.version), optarg); break;
        case 'h': copy_string(g_cfg.hostname, sizeof(g_cfg.hostname), optarg); break;
        case 'n': copy_string(g_cfg.instance, sizeof(g_cfg.instance), optarg); break;
        default: return false;
        }
    }

    if (g_cfg.iface[0] == '\0' || if_nametoindex(g_cfg.iface) == 0) {
        fprintf(stderr, "Interface does not exist: %s\n", g_cfg.iface);
        return false;
    }
    if (inet_pton(AF_INET, g_cfg.ip, &g_ip_addr) != 1) {
        fprintf(stderr, "Invalid IPv4 address: %s\n", g_cfg.ip);
        return false;
    }

    sanitize_hostname(g_cfg.hostname);
    sanitize_instance(g_cfg.instance);
    snprintf(g_host_fqdn, sizeof(g_host_fqdn), "%s.local", g_cfg.hostname);
    snprintf(g_instance_fqdn, sizeof(g_instance_fqdn), "%s.%s", g_cfg.instance, g_service_type);
    return true;
}

static bool get_interface_mac(const char *iface, char *out, size_t out_size)
{
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0)
        return false;
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    copy_string(ifr.ifr_name, sizeof(ifr.ifr_name), iface);
    bool ok = ioctl(fd, SIOCGIFHWADDR, &ifr) == 0;
    if (ok) {
        const unsigned char *mac = (const unsigned char *)ifr.ifr_hwaddr.sa_data;
        snprintf(out, out_size, "%02x:%02x:%02x:%02x:%02x:%02x",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    }
    close(fd);
    return ok;
}

static bool set_nonblocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    return flags >= 0 && fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
}

static bool buffer_append(struct buffer *buf, const void *data, size_t size)
{
    if (!buf || !data || buf->len + size > sizeof(buf->data))
        return false;
    memcpy(buf->data + buf->len, data, size);
    buf->len += size;
    return true;
}

static bool append_u16(struct buffer *buf, uint16_t value)
{
    uint16_t network = htons(value);
    return buffer_append(buf, &network, sizeof(network));
}

static bool append_u32(struct buffer *buf, uint32_t value)
{
    uint32_t network = htonl(value);
    return buffer_append(buf, &network, sizeof(network));
}

static bool encode_name(struct buffer *buf, const char *name)
{
    const char *cursor = name;
    while (*cursor) {
        const char *dot = strchr(cursor, '.');
        size_t length = dot ? (size_t)(dot - cursor) : strlen(cursor);
        if (length == 0 || length > 63)
            return false;
        uint8_t len8 = (uint8_t)length;
        if (!buffer_append(buf, &len8, 1) || !buffer_append(buf, cursor, length))
            return false;
        if (!dot)
            break;
        cursor = dot + 1;
    }
    uint8_t zero = 0;
    return buffer_append(buf, &zero, 1);
}

static bool append_record(struct buffer *packet, const char *name, uint16_t type,
                          uint16_t rr_class, uint32_t ttl,
                          const uint8_t *rdata, size_t rdata_len)
{
    if (rdata_len > UINT16_MAX)
        return false;
    return encode_name(packet, name) &&
           append_u16(packet, type) &&
           append_u16(packet, rr_class) &&
           append_u32(packet, ttl) &&
           append_u16(packet, (uint16_t)rdata_len) &&
           buffer_append(packet, rdata, rdata_len);
}

static bool build_txt(struct buffer *txt)
{
    char id[MAX_TEXT];
    char model[MAX_TEXT];
    char version[MAX_TEXT];
    char mac[MAX_TEXT];
    snprintf(id, sizeof(id), "id=E70640 %s", g_cfg.serial);
    snprintf(model, sizeof(model), "model=Raymarine YachtSense Link");
    snprintf(version, sizeof(version), "version=%s", g_cfg.version);
    snprintf(mac, sizeof(mac), "mac=%s", g_mac);
    const char *items[] = {id, model, version, mac};

    for (size_t i = 0; i < sizeof(items) / sizeof(items[0]); i++) {
        size_t len = strlen(items[i]);
        if (len > 255)
            return false;
        uint8_t len8 = (uint8_t)len;
        if (!buffer_append(txt, &len8, 1) || !buffer_append(txt, items[i], len))
            return false;
    }
    return true;
}

static bool build_mdns_response(struct buffer *packet, uint32_t ttl)
{
    memset(packet, 0, sizeof(*packet));
    uint8_t header[12] = {0};
    header[2] = 0x84;
    header[3] = 0x00;
    header[6] = 0x00;
    header[7] = 0x05;
    if (!buffer_append(packet, header, sizeof(header)))
        return false;

    struct buffer ptr_instance = {0};
    struct buffer srv = {0};
    struct buffer txt = {0};
    struct buffer ptr_service = {0};

    if (!encode_name(&ptr_instance, g_instance_fqdn))
        return false;
    if (!append_u16(&srv, 0) || !append_u16(&srv, 0) || !append_u16(&srv, 80) ||
        !encode_name(&srv, g_host_fqdn))
        return false;
    if (!build_txt(&txt))
        return false;
    if (!encode_name(&ptr_service, g_service_type))
        return false;

    return append_record(packet, g_service_type, 12, 0x0001, ttl,
                         ptr_instance.data, ptr_instance.len) &&
           append_record(packet, g_instance_fqdn, 33, 0x8001, ttl,
                         srv.data, srv.len) &&
           append_record(packet, g_instance_fqdn, 16, 0x8001, ttl,
                         txt.data, txt.len) &&
           append_record(packet, g_host_fqdn, 1, 0x8001, ttl,
                         (const uint8_t *)&g_ip_addr, sizeof(g_ip_addr)) &&
           append_record(packet, g_services_browse, 12, 0x0001, ttl,
                         ptr_service.data, ptr_service.len);
}

static bool decode_dns_name(const uint8_t *packet, size_t packet_len, size_t start,
                            char *out, size_t out_size, size_t *next_offset, int depth)
{
    if (!packet || !out || out_size == 0 || depth > 12 || start >= packet_len)
        return false;

    size_t offset = start;
    size_t output_len = 0;
    bool jumped = false;
    size_t after_name = start;

    while (offset < packet_len) {
        uint8_t length = packet[offset];
        if (length == 0) {
            if (!jumped)
                after_name = offset + 1;
            out[output_len] = '\0';
            if (next_offset)
                *next_offset = after_name;
            return true;
        }
        if ((length & 0xc0) == 0xc0) {
            if (offset + 1 >= packet_len)
                return false;
            size_t pointer = ((size_t)(length & 0x3f) << 8) | packet[offset + 1];
            if (!jumped)
                after_name = offset + 2;
            jumped = true;
            char nested[MAX_NAME];
            if (!decode_dns_name(packet, packet_len, pointer, nested, sizeof(nested), NULL, depth + 1))
                return false;
            size_t nested_len = strlen(nested);
            if (output_len && output_len + 1 < out_size)
                out[output_len++] = '.';
            if (output_len + nested_len >= out_size)
                return false;
            memcpy(out + output_len, nested, nested_len + 1);
            output_len += nested_len;
            if (next_offset)
                *next_offset = after_name;
            return true;
        }
        if (length > 63 || offset + 1 + length > packet_len)
            return false;
        if (output_len && output_len + 1 < out_size)
            out[output_len++] = '.';
        if (output_len + length >= out_size)
            return false;
        for (uint8_t i = 0; i < length; i++) {
            char c = (char)packet[offset + 1 + i];
            if (c >= 'A' && c <= 'Z')
                c = (char)(c - 'A' + 'a');
            out[output_len++] = c;
        }
        offset += 1 + length;
        if (!jumped)
            after_name = offset;
    }
    return false;
}

static bool query_is_interesting(const uint8_t *packet, size_t packet_len)
{
    if (packet_len < 12 || (packet[2] & 0x80))
        return false;
    uint16_t qdcount = (uint16_t)((packet[4] << 8) | packet[5]);
    size_t offset = 12;

    char service_lower[MAX_NAME];
    char instance_lower[MAX_NAME];
    char host_lower[MAX_NAME];
    char browse_lower[MAX_NAME];
    copy_string(service_lower, sizeof(service_lower), g_service_type);
    copy_string(instance_lower, sizeof(instance_lower), g_instance_fqdn);
    copy_string(host_lower, sizeof(host_lower), g_host_fqdn);
    copy_string(browse_lower, sizeof(browse_lower), g_services_browse);
    for (char *p = service_lower; *p; p++) if (*p >= 'A' && *p <= 'Z') *p += 32;
    for (char *p = instance_lower; *p; p++) if (*p >= 'A' && *p <= 'Z') *p += 32;
    for (char *p = host_lower; *p; p++) if (*p >= 'A' && *p <= 'Z') *p += 32;
    for (char *p = browse_lower; *p; p++) if (*p >= 'A' && *p <= 'Z') *p += 32;

    for (uint16_t i = 0; i < qdcount; i++) {
        char name[MAX_NAME];
        size_t next = 0;
        if (!decode_dns_name(packet, packet_len, offset, name, sizeof(name), &next, 0))
            return false;
        offset = next;
        if (offset + 4 > packet_len)
            return false;
        offset += 4;
        if (!strcmp(name, service_lower) || !strcmp(name, instance_lower) ||
            !strcmp(name, host_lower) || !strcmp(name, browse_lower))
            return true;
    }
    return false;
}

static int create_mdns_socket(void)
{
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        syslog(LOG_ERR, "Cannot create mDNS socket: %s", strerror(errno));
        return -1;
    }

    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
#ifdef SO_REUSEPORT
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &yes, sizeof(yes));
#endif
    if (setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, g_cfg.iface, strlen(g_cfg.iface) + 1) < 0)
        syslog(LOG_WARNING, "SO_BINDTODEVICE(%s) failed: %s", g_cfg.iface, strerror(errno));

    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(MDNS_PORT);
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        syslog(LOG_ERR, "Cannot bind UDP/%d on %s: %s", MDNS_PORT, g_cfg.iface, strerror(errno));
        close(fd);
        return -1;
    }

    struct ip_mreqn membership;
    memset(&membership, 0, sizeof(membership));
    inet_pton(AF_INET, MDNS_GROUP, &membership.imr_multiaddr);
    membership.imr_address = g_ip_addr;
    membership.imr_ifindex = (int)if_nametoindex(g_cfg.iface);
    if (setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &membership, sizeof(membership)) < 0) {
        syslog(LOG_ERR, "Cannot join mDNS multicast on %s/%s: %s",
               g_cfg.iface, g_cfg.ip, strerror(errno));
        close(fd);
        return -1;
    }

    if (setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &membership, sizeof(membership)) < 0) {
        struct in_addr local = g_ip_addr;
        if (setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &local, sizeof(local)) < 0)
            syslog(LOG_WARNING, "Cannot select mDNS multicast interface: %s", strerror(errno));
    }
    unsigned char ttl = 255;
    unsigned char loop = 0;
    setsockopt(fd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl));
    setsockopt(fd, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof(loop));
    set_nonblocking(fd);
    return fd;
}

static void send_mdns_announcement(uint32_t ttl)
{
    if (g_mdns_fd < 0)
        return;
    struct buffer packet;
    if (!build_mdns_response(&packet, ttl)) {
        syslog(LOG_ERR, "Failed to build mDNS response packet");
        return;
    }
    struct sockaddr_in destination;
    memset(&destination, 0, sizeof(destination));
    destination.sin_family = AF_INET;
    destination.sin_port = htons(MDNS_PORT);
    inet_pton(AF_INET, MDNS_GROUP, &destination.sin_addr);
    ssize_t sent = sendto(g_mdns_fd, packet.data, packet.len, 0,
                          (struct sockaddr *)&destination, sizeof(destination));
    if (sent < 0)
        syslog(LOG_WARNING, "mDNS send failed: %s", strerror(errno));
}

static int create_web_socket(void)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        syslog(LOG_ERR, "Cannot create HTTP socket: %s", strerror(errno));
        return -1;
    }
    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    if (setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, g_cfg.iface, strlen(g_cfg.iface) + 1) < 0)
        syslog(LOG_WARNING, "HTTP SO_BINDTODEVICE(%s) failed: %s", g_cfg.iface, strerror(errno));

    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons((uint16_t)g_cfg.web_port);
    address.sin_addr = g_ip_addr;
    if (bind(fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        syslog(LOG_ERR, "Cannot bind HTTP %s:%d: %s", g_cfg.ip, g_cfg.web_port, strerror(errno));
        close(fd);
        return -1;
    }
    if (listen(fd, 8) < 0) {
        syslog(LOG_ERR, "Cannot listen on HTTP %s:%d: %s", g_cfg.ip, g_cfg.web_port, strerror(errno));
        close(fd);
        return -1;
    }
    set_nonblocking(fd);
    return fd;
}

static void handle_http_connection(void)
{
    struct sockaddr_in peer;
    socklen_t peer_len = sizeof(peer);
    int client = accept(g_web_fd, (struct sockaddr *)&peer, &peer_len);
    if (client < 0) {
        if (errno != EAGAIN && errno != EWOULDBLOCK)
            syslog(LOG_WARNING, "HTTP accept failed: %s", strerror(errno));
        return;
    }

    struct timeval timeout = {.tv_sec = 2, .tv_usec = 0};
    setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    char request[1024];
    (void)recv(client, request, sizeof(request) - 1, 0);

    char body[512];
    int body_len = snprintf(body, sizeof(body),
                            "{\"status\":\"ok\",\"id\":\"E70640 %s\","
                            "\"model\":\"Raymarine YachtSense Link\","
                            "\"version\":\"%s\",\"ip\":\"%s\"}\n",
                            g_cfg.serial, g_cfg.version, g_cfg.ip);
    if (body_len < 0)
        body_len = 0;
    if ((size_t)body_len >= sizeof(body))
        body_len = (int)sizeof(body) - 1;

    char response[1024];
    int response_len = snprintf(response, sizeof(response),
                                "HTTP/1.1 200 OK\r\n"
                                "Content-Type: application/json\r\n"
                                "Content-Length: %d\r\n"
                                "Connection: close\r\n"
                                "Cache-Control: no-store\r\n\r\n%s",
                                body_len, body);
    if (response_len > 0) {
        if ((size_t)response_len > sizeof(response))
            response_len = (int)sizeof(response);
        (void)send(client, response, (size_t)response_len, MSG_NOSIGNAL);
    }

    char peer_ip[INET_ADDRSTRLEN] = "unknown";
    inet_ntop(AF_INET, &peer.sin_addr, peer_ip, sizeof(peer_ip));
    syslog(LOG_INFO, "HTTP probe answered for %s", peer_ip);
    close(client);
}

int main(int argc, char **argv)
{
    if (!parse_args(argc, argv)) {
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    openlog("yachtsense-emulator", LOG_PID | LOG_NDELAY, LOG_DAEMON);
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
    signal(SIGPIPE, SIG_IGN);
    get_interface_mac(g_cfg.iface, g_mac, sizeof(g_mac));

    if (!g_cfg.mdns_enabled && !g_cfg.web_enabled) {
        syslog(LOG_NOTICE, "No components enabled; exiting");
        closelog();
        return EXIT_SUCCESS;
    }

    if (g_cfg.mdns_enabled) {
        g_mdns_fd = create_mdns_socket();
        if (g_mdns_fd < 0) {
            closelog();
            return EXIT_FAILURE;
        }
        syslog(LOG_NOTICE,
               "mDNS enabled on %s (%s): %s._http._tcp.local id=E70640 %s",
               g_cfg.iface, g_cfg.ip, g_cfg.instance, g_cfg.serial);
        send_mdns_announcement(DNS_TTL);
    }

    if (g_cfg.web_enabled) {
        g_web_fd = create_web_socket();
        if (g_web_fd < 0) {
            if (g_mdns_fd >= 0) {
                send_mdns_announcement(0);
                close(g_mdns_fd);
            }
            closelog();
            return EXIT_FAILURE;
        }
        syslog(LOG_NOTICE, "HTTP probe service enabled on http://%s:%d/", g_cfg.ip, g_cfg.web_port);
    }

    syslog(LOG_NOTICE, "YachtSense Link emulator started");
    time_t next_announcement = time(NULL) + ANNOUNCE_INTERVAL;

    while (g_running) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        int max_fd = -1;
        if (g_mdns_fd >= 0) {
            FD_SET(g_mdns_fd, &read_fds);
            if (g_mdns_fd > max_fd) max_fd = g_mdns_fd;
        }
        if (g_web_fd >= 0) {
            FD_SET(g_web_fd, &read_fds);
            if (g_web_fd > max_fd) max_fd = g_web_fd;
        }

        struct timeval timeout = {.tv_sec = 1, .tv_usec = 0};
        int result = select(max_fd + 1, &read_fds, NULL, NULL, &timeout);
        if (result < 0 && errno != EINTR) {
            syslog(LOG_ERR, "select failed: %s", strerror(errno));
            break;
        }

        if (result > 0 && g_mdns_fd >= 0 && FD_ISSET(g_mdns_fd, &read_fds)) {
            uint8_t packet[MAX_PACKET];
            ssize_t received = recvfrom(g_mdns_fd, packet, sizeof(packet), 0, NULL, NULL);
            if (received > 0 && query_is_interesting(packet, (size_t)received)) {
                send_mdns_announcement(DNS_TTL);
                syslog(LOG_DEBUG, "Answered YachtSense mDNS query");
            }
        }
        if (result > 0 && g_web_fd >= 0 && FD_ISSET(g_web_fd, &read_fds))
            handle_http_connection();

        time_t now = time(NULL);
        if (g_mdns_fd >= 0 && now >= next_announcement) {
            send_mdns_announcement(DNS_TTL);
            next_announcement = now + ANNOUNCE_INTERVAL;
        }
    }

    if (g_mdns_fd >= 0) {
        send_mdns_announcement(0);
        usleep(100000);
        close(g_mdns_fd);
    }
    if (g_web_fd >= 0)
        close(g_web_fd);
    syslog(LOG_NOTICE, "YachtSense Link emulator stopped");
    closelog();
    return EXIT_SUCCESS;
}
